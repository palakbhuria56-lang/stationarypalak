# Palak Stationary

Single-page stationery e-commerce website using HTML, CSS and JavaScript.

## Media
The background wallpaper is the original `spring-meadow.3840x2160.mp4` file.
It is included byte-for-byte in `media/` and is not resized or re-encoded.

## GitHub
Upload the complete folder contents to a GitHub repository. Keep the `media` folder beside `index.html`.

Open `index.html` locally to preview the site.
